﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace cityguide.View
{
    public partial class AboutPageView : CarouselPage
    {
        public AboutPageView()
        {
            InitializeComponent();
        }
    }
}
