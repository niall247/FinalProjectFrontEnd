﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace cityguide.View
{
    public partial class TabPage : TabbedPage
    {
        public TabPage()
        {
            InitializeComponent();
        }
    }
}
